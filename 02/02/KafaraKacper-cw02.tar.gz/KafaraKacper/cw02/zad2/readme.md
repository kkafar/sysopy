## Uruchamianie

1. Wykonanie polecenia `make` skutkuje powstaniem dwoch plikow wykonywalnych *main_lib* oraz *main_sys* -- wykorzystujacych odpowniednie funkcje (wyspecyfokowane w tresci zadania).

2. Testy (wraz z pomiarem czasu) mozna przeprowadzic wykonujac polecenie `make test`. Rezultaty zostana automatycznie zapisane do pliku *pomiar_zad_2.txt*.