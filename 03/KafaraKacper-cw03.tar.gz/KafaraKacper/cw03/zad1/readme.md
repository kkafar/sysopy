## Uruchamianie 

1. Kompilacja poleceniem `make`.
2. Uruchomienie polecenim `./main <liczba procesow potomnych>`.



## Dostepne polecenia

1. `make test` testuje program dla 4 procesow potomnych
2. `make clean` usuwa wszystkie pliki z rozszerzeniem .o
3. `make clean_all` usuwa wszystkie pliki z rozszerzeniem .o wraz z plikiem wykonywalnym `main`

